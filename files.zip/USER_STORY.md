```
As an entrepreneur in Nairobi,
I want to list my cleaning business and staff on GloBOS,
So that customers nearby can find and book my services,
I can schedule staff shifts, handle payments, track deliveries,
And manage documents and compliance in one dashboard.
```